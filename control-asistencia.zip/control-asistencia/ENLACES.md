# Enlaces para el informe

Reemplace `<usuario>` por su usuario u organización de GitHub (y `main` por la rama, si usa otra).

## Desarrollo Frontend
El código fuente correspondiente al desarrollo frontend, disponible en los siguientes enlaces:
- Repositorio general: https://github.com/<usuario>/control-asistencia
- Directorio de vista: https://github.com/<usuario>/control-asistencia/tree/main/app/presentacion

## Desarrollo Backend
El código fuente correspondiente al desarrollo backend, disponible en los siguientes enlaces:
- Directorio de lógica de negocio: https://github.com/<usuario>/control-asistencia/tree/main/app/negocio
- Directorio de acceso a datos: https://github.com/<usuario>/control-asistencia/tree/main/app/datos
- Otros archivos de configuración: https://github.com/<usuario>/control-asistencia/tree/main/config
- Migraciones: https://github.com/<usuario>/control-asistencia/tree/main/migrations

## Cómo subir el proyecto a GitHub (una sola vez)
1. En github.com → New repository → nombre `control-asistencia` → Public → Create repository (sin README).
2. En la carpeta del proyecto:
   ```bash
   git init
   git add .
   git commit -m "Sistema de control de asistencia en 3 capas"
   git branch -M main
   git remote add origin https://github.com/<usuario>/control-asistencia.git
   git push -u origin main
   ```
3. Abra cada enlace de arriba para comprobar que carga la carpeta correcta.
